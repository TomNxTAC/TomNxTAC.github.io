/*
  You have come to the right place!

  This function gets called for you somewhere else.
  You just have to modify it to run your own instructions!
*/


function picasso(){
  // Replace with your own instructions
  moveDown(4);
  moveLeft(4);
  drawLineUp(8);
  drawLineRight(6);
  drawLineDown(8);
  moveUp(4);
  drawLineLeft(6);
}
